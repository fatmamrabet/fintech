def format_currency(amount):
    return round(amount, 2)


def add(a, b):
    return a + b
